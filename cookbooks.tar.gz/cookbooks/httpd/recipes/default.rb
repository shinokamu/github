#
# Cookbook Name:: httpd
# Recipe:: default
#
# Copyright 2013, YOUR_COMPANY_NAME
#
# All rights reserved - Do Not Redistribute
#

package 'httpd' do
        action :install
end

service "httpd" do
  action :restart
end

template "index.html" do
	path "/var/www/html/index.html"
	source "index.erb"
	owner "root"
	group "root"
	mode 0644
	variables({
	    :hostname => `/bin/hostname`.chomp
	  })
end

